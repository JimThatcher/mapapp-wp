﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Device.Location;
using Microsoft.Phone.Controls.Maps;
using System.Collections.ObjectModel;

namespace mapapp
{
    public class PushpinModel
    {
        public GeoCoordinate Location { get; set; }
        public bool Valid { get; set; }

        public Visibility Visibility { get; set; }
        public string Content { get; set; }
        // public string FullContent { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Phone { get; set; }
        public string RecordID { get; set; }
        public string party { get; set; }
        public string precinct { get; set; }
        public string PrimaryVoteHistory { get; set; }
        public string GeneralVoteHistory { get; set; }
        private string _street = null;
        public string Street 
        { 
            get
            {
                if ((this.Address != null) && (_street == null || _street.Length <= 0))
                {
                    _street = this.Address.Substring(this.Address.IndexOf(' ') + 1);
                }
                return _street;
            }
        }

        private int _housenum = 0;
        public int HouseNum 
        {
            get
            {
                if ((this.Address != null) && (_housenum == 0))
                {
                    int nHouseNum = 0;
                    string strHouseNum = this.Address.Substring(0, this.Address.IndexOf(' '));
                    if (Int32.TryParse(strHouseNum, out nHouseNum))
                        _housenum = nHouseNum;
                }
                return _housenum;
            }
        }

        public bool IsEven 
        {
            get
            {
                bool bEven = false;
                if (this.HouseNum != 0)
                    bEven = (_housenum % 2) == 0;
                return bEven;
            }
        }

        public string FullName 
        {
            get
            {
                return LastName + ", " + FirstName;
            }
        }
        public string VotingHistory { get; set; }
        public long VoterID { get; set; }
        // public bool IsSelected { get; set; }
        public bool WillVote { get; set; }
        public bool WantsSign { get; set; }
        public bool WillHost { get; set; }
        public bool WillDonate { get; set; }
        public string Email { get; set; }
        public string CellPhone { get; set; }

        // TODO: These should be moved to the viewmodel
        public Brush Background { get; set; }
        public Brush Foreground { get; set; }
        public double dist = 0.0;

        public string LatLong 
        { 
            set
            {
                string [] latlong = value.Split(',');
                double lat = 0.0;
                double lon = 0.0;

                if (latlong.Length != 2)
                {
                    Valid = false;
                    return;
                }

                double.TryParse(latlong[0], out lat);
                double.TryParse(latlong[1], out lon);

                Location = new GeoCoordinate(lat, lon);
                Valid = true;
            }
        }

        public PushpinModel Clone(GeoCoordinate location)
        {
            return new PushpinModel
            {
                Location = location,
                //TypeName = TypeName,
                //Icon = Icon
            };
        }



    }

}
