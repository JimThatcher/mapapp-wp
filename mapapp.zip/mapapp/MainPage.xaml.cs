﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Device.Location;
using Microsoft.Phone.Controls.Maps;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;
using System.Windows.Resources;
using System.Windows.Threading;
using System.Threading;

namespace mapapp
{
    
    public partial class MainPage : PhoneApplicationPage, INotifyPropertyChanged
    {
        
        internal const string Id = "AgTD8VcX7TSsg5eldqc4Pmhs0ST2L2GGYt4P9vPJZM9ijZTYsmzCmet-6Va1oX8d";
        private readonly CredentialsProvider _credentialsProvider = new ApplicationIdCredentialsProvider(Id);
        public static readonly GeoCoordinate DefaultLocation = new GeoCoordinate(47.651664, -122.033827);
        private const double DefaultZoomLevel = 18.0;
        private const double MaxZoomLevel = 21.0;
        private const double MinZoomLevel = 10.0;
        private double _zoom;
        private GeoCoordinate _center;
        public event PropertyChangedEventHandler PropertyChanged;
        GeoCoordinateWatcher watcher;
        private bool firstfind = true;
        List<PushpinModel> listModels = new List<PushpinModel>();
        private bool hidePushpins = false;
       
        private bool follow = true;
        Thread backThread;
        ManualResetEvent wait = new ManualResetEvent(false);

        quadtree tree = new quadtree();
        double zoomlevel = 0.0;

        PushpinModel me;
        bool running = true;
        
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            DataContext = this;

            me = new PushpinModel();
            me.Content = "Me";
            me.Visibility = Visibility.Collapsed;
            me.Background = new SolidColorBrush(Colors.White);
            me.Foreground = new SolidColorBrush(Colors.Black);

            Map.MapZoom += new EventHandler<MapZoomEventArgs>(MapZoomed);
            Map.MapPan += new EventHandler<MapDragEventArgs>(MapDragged);
            watcher = new GeoCoordinateWatcher(GeoPositionAccuracy.High); // using high accuracy
            watcher.MovementThreshold = 0.1; // use MovementThreshold to ignore noise in the signal
            
            watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
            watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);

            watcher.Start();
            
            CenterLocation();

            backThread = new Thread(BackgroundThread);
            backThread.Start();
            Zoom = MinZoomLevel;
            zoomlevel = MinZoomLevel;

        }

        public void BackgroundThread()
        {
            LoadPushPins();

            while (wait.WaitOne())
            {
                wait.Reset();

                if (running == false)
                {
                    return;
                }

                LocationRect lr = Map.BoundingRectangle;

                LocationRect alr = lr;

                double west = lr.West - (lr.East - lr.West) / 3.0;
                double east = lr.East + (lr.East - lr.West) / 3.0;
                double north = lr.North + (lr.North - lr.South) / 3.0;
                double south = lr.South - (lr.North - lr.South) / 3.0;

                bool bfullcontent = false;

                if (zoomlevel < 14.0)
                {
                    continue;
                }

                if (zoomlevel > 18.0)
                {
                    bfullcontent = true;
                }

                List<PushpinModel> l = tree.Search(lr.South, lr.North, lr.West, lr.East);
                int total = 0;

                if (wait.WaitOne(0))
                {
                    continue;
                }

                foreach (PushpinModel p in l)
                {
                    //distance calculation
                    double lat = lr.Center.Latitude - p.Location.Latitude;
                    double lon = lr.Center.Longitude - p.Location.Longitude;
                    double dist = Math.Sqrt((lat * lat) + (lon * lon));
                    p.dist = dist;

                    if (wait.WaitOne(0))
                    {
                        break;
                    }
                }

                if (wait.WaitOne(0))
                {
                    continue;
                }

                Comparison<PushpinModel> c = new Comparison<PushpinModel>(SortDistance);
                l.Sort(c);

                if (wait.WaitOne(0))
                {
                    continue;
                }

                listModels.Clear();
                foreach (PushpinModel p in l)
                {
                    total++;

                    if (bfullcontent)
                    {
                        p.Content = p.FullName + "\r" + p.Address + " " + p.Address2;
                    }
                    else 
                    {
                        p.Content = p.LastName;
                    }

                    listModels.Add(p);

                    if (false == (west <= p.Location.Longitude && east >= p.Location.Longitude &&
                       north >= p.Location.Latitude && south <= p.Location.Latitude))
                    {
                        break;
                    }

                    // TEST: Can we eliminate this break, allowing unlimited number of pushpins?
                    // If the zoomlevel is zoomed out too far we should skip all of this, so that should serve as a failsafe
                    if (total == 30)
                    {
                        break;
                    }

                    if (wait.WaitOne(0))
                    {
                        break;
                    }
                }

                listModels.Add(me);

                if (wait.WaitOne(0))
                {
                    continue;
                }

                Dispatcher.BeginInvoke(UpdatePins);
            }
        }

        public void UpdatePins()
        {
            Pushpins.Clear();
            foreach (PushpinModel p in listModels)
            {
                if (null == p.Background)
                {
                    p.FirstName = p.FirstName.Trim();
                    p.LastName = p.LastName.Trim();
                    p.Address = p.Address.Trim();
                    p.Address2 = p.Address2.Trim();
                    p.City = p.City.Trim();
                    p.State = p.State.Trim();
                    p.Zip = p.Zip.Trim();
                    p.Phone = FormatPhone(p.Phone);
                    p.party = p.party.Trim();
                    p.RecordID = p.RecordID.Trim();

                    // p.FullContent = p.LastName + ", " + p.FirstName + "\r" + p.Address + " " + p.Address2 + "\r" + p.Phone;
                    p.Content = p.LastName;

                    // p.FullName = p.LastName + ", " + p.FirstName;
                    // TODO: This should be moved to the viewmodel
                    if (p.party == "0")
                    {
                        // unknown
                        p.Background = new SolidColorBrush(Colors.White);
                        p.Foreground = new SolidColorBrush(Colors.Black);
                    }
                    else if (p.party == "1")
                    {
                        // strong republican
                        p.Background = new SolidColorBrush(Colors.Red);
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else if (p.party == "2")
                    {
                        // moderate republican
                        p.Background = new SolidColorBrush(Color.FromArgb(0xff, 0xff, 0x88, 0x88));
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else if (p.party == "3")
                    {
                        // independent
                        p.Background = new SolidColorBrush(Colors.Purple);
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else if (p.party == "4")
                    {
                        // soft dem
                        p.Background = new SolidColorBrush(Color.FromArgb(0xff, 0x88, 0x88, 0xff));
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else if (p.party == "5")
                    {
                        // hard dem
                        p.Background = new SolidColorBrush(Colors.Blue);
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }
                    else if (p.party == "6")
                    {
                        // won't say
                        p.Background = new SolidColorBrush(Colors.Black);
                        p.Foreground = new SolidColorBrush(Colors.White);
                    }

                }

                if (hidePushpins && (p.Content != "Me"))
                    p.Visibility = System.Windows.Visibility.Collapsed;
                else
                    p.Visibility = System.Windows.Visibility.Visible;

                Pushpins.Add(p);
            }
            NotifyPropertyChanged("Pushpins");
        }

        public void MapDragged(object o, MapDragEventArgs e)
        {
            zoomlevel = Map.ZoomLevel;
            follow = false;
            wait.Set();
        }

        public void MapZoomed(object o, MapZoomEventArgs e)
        {
            zoomlevel = Map.ZoomLevel;
            wait.Set();
        }

        int SortDistance(PushpinModel p1, PushpinModel p2)
        {
            if (p1.dist > p2.dist)
            {
                return 1;
            }
            else if (p1.dist < p2.dist)
            {
                return -1;
            }


            return 0;
        }


        public CredentialsProvider CredentialsProvider
        {
            get { return _credentialsProvider; }
        }

        public void LoadPushPins()
        {
            double lat1 = -9999.0;
            double lat2 = -9999.0;
            double long1 = -9999.0;
            double long2 = -9999.0;
            /*
    <pins>
      <pin>
        <address>904 211th Pl NE</address>
        <address2></address2>
        <city>Sammamish</city>
        <state>WA</state>
        <zip>98074</zip>
        <phone></phone>
        <lastname>A</lastname>
        <firstname>FARIDA</firstname>
        <precinct>SAM 05/0536</precinct>
        <party>0</party>
        <pvscore><pri>0</pri><gen>1</gen></pvscore>
        <recid>9308654298</recid>
        <location>47.617831,-122.058112</location>
      </pin>
    </pins>
             */

            XDocument loadedData = XDocument.Load("voters.xml");
            IEnumerable<PushpinModel> data = from query in loadedData.Descendants("pin")
                                             select new PushpinModel
                                          {
                                              FirstName = (string)query.Element("firstname"),
                                              LastName = (string)query.Element("lastname"),
                                              Address = (string)query.Element("address"),
                                              Address2 = (string)query.Element("address2"),
                                              City = (string)query.Element("city"),
                                              State = (string)query.Element("state"),
                                              Zip = (string)query.Element("zip"),
                                              Phone = (string)query.Element("phone"),
                                              Email = (string)query.Element("email"),
                                              LatLong = (string)query.Element("location"),
                                              RecordID = (string)query.Element("recid"),
                                              party = (string)query.Element("party"),
                                              precinct = (string)query.Element("precinct"),
                                              PrimaryVoteHistory = (string)query.Element("pvscore").Element("pri"),
                                              GeneralVoteHistory = (string)query.Element("pvscore").Element("gen")
                                          };

            foreach (PushpinModel p in data)
            {
                if (0.0 == p.Location.Latitude || 0.0 == p.Location.Longitude)
                {
                    continue;
                }

                if (-9999.0 == lat1 || p.Location.Latitude < lat1)
                {
                    lat1 = p.Location.Latitude;
                }

                if (-9999.0 == lat2 || p.Location.Latitude > lat2)
                {
                    lat2 = p.Location.Latitude;
                }

                if (-9999.0 == long1 || p.Location.Longitude < long1)
                {
                    long1 = p.Location.Longitude;
                }

                if (-9999.0 == long2 || p.Location.Longitude > long2)
                {
                    long2 = p.Location.Longitude;
                }

                if (p.Valid)
                {
                    tree.AddNode(p);
                    p.Visibility = Visibility.Visible;
                }
            }

            tree.latmin = lat1;
            tree.latmax = lat2;
            tree.longmin = long1;
            tree.longmax = long2;


            tree.BuildTree();


        }

        private void ChangeMapMode(object o, EventArgs e)
        {
            if (Map.Mode is AerialMode)
            {
                Map.Mode = new RoadMode();
            }
            else
            {
                Map.Mode = new AerialMode(true);
            }
        }
        
        private void Follow(object o, EventArgs e)
        {
            follow = true;
        }

        public double Zoom
        {
            get { return _zoom; }
            set
            {
                var coercedZoom = Math.Max(MinZoomLevel, Math.Min(MaxZoomLevel, value));
                if (_zoom != coercedZoom)
                {
                    _zoom = value;
                    NotifyPropertyChanged("Zoom");
                }
            }
        }

        public GeoCoordinate Center
        {
            get { return _center; }
            set
            {
                if (_center != value)
                {
                    _center = value;

                    NotifyPropertyChanged("Center");

                }
            }
        }

        private void CenterLocation()
        {
            if (null != me)
            {
                Center = me.Location;
            }
        }

        private void CreateNewPushpin(GeoCoordinate location)
        {
            PushpinModel p = new PushpinModel();
            p.Location = location;
            Pushpins.Add(p);
        }

        

        private readonly ObservableCollection<PushpinModel> _pushpins = new ObservableCollection<PushpinModel>
        {

        };

        public ObservableCollection<PushpinModel> Pushpins
        {
            get { return _pushpins; }
        }

        public void ZoomOut(object sender, EventArgs e)
        {
            Zoom = MinZoomLevel;
        }

        public void NotifyPropertyChanged(string propertyName)
        {

            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }

        }

        private void Center_Click(object sender, EventArgs e)
        {
            CenterLocation();
            follow = true;
            NotifyPropertyChanged("Pushpins");
        }

        // Event handler for the GeoCoordinateWatcher.StatusChanged event.
        void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            switch (e.Status)
            {
                case GeoPositionStatus.Disabled:
                    // The Location Service is disabled or unsupported.
                    // Check to see whether the user has disabled the Location Service.
                    if (watcher.Permission == GeoPositionPermission.Denied)
                    {
                        watcher.Stop();
                    }
                    else
                    {
                        watcher.Stop();
                    }
                    break;

                case GeoPositionStatus.Initializing:
                    break;

                case GeoPositionStatus.NoData:
                    watcher.Stop();
                    break;

                case GeoPositionStatus.Ready:
                    break;
            }
        }

        void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        {
            if (null == me)
            {
                return;
            }

            Pushpins.Remove(me);
            me.Visibility = Visibility.Visible;
            me.LatLong = e.Position.Location.Latitude.ToString("0.000") + "," + e.Position.Location.Longitude.ToString("0.000");
            Pushpins.Add(me);


            if (firstfind || follow)
            {
                CenterLocation();
            }

            if (firstfind)
            {
                Zoom = DefaultZoomLevel;
                firstfind = false;
            }

            NotifyPropertyChanged("Pushpins");

        }

        private string FormatPhone(string p)
        {
            string o = "";
            int digits = 0;
            p = p.Trim();

            foreach (char c in p)
            {
                if (char.IsDigit(c))
                {
                    digits++;
                    o = o + c;
                    if (digits == 3 || digits == 6)
                    {
                        o = o + ".";
                    }
                }
            }

            return o;
        }

        private void ListStreets(object sender, EventArgs e)
        {
            List<String> listofStreets = new List<string>();

            lstStreetList.Items.Clear();
            listofStreets.Clear();
            lstStreetList.SelectedIndex = -1;
            App.VotersViewModel.Clear();
            foreach (PushpinModel p in listModels)
            {
                if ((p.Street != null) && (!listofStreets.Contains(p.Street)))
                {
                    lstStreetList.Items.Add(p.Street);
                    listofStreets.Add(p.Street);
                }
            }
            lstStreetList.Visibility = System.Windows.Visibility.Visible;
        }

        private void OnStreetSelected(object sender, SelectionChangedEventArgs e)
        {
            lstStreetList.Visibility = System.Windows.Visibility.Collapsed;
            ListBox lbStreets = sender as ListBox;
            if (lbStreets != null && lbStreets.SelectedIndex == -1)
                return;

            foreach (PushpinModel p in listModels)
            {
                if (p.Address != null)
                {
                    if (lbStreets != null && lbStreets.SelectedItem != null && p.Address.Contains(lbStreets.SelectedItem as String))
                    {
                        App.VotersViewModel.Add(p);
                    }
                }
            }
            this.NavigationService.Navigate(new Uri("/HouseListPage.xaml", UriKind.Relative));
        }

        private void PhoneApplicationPage_BackKeyPress(object sender, CancelEventArgs e)
        {
            if (lstStreetList.Visibility == System.Windows.Visibility.Visible)
            {
                lstStreetList.Visibility = System.Windows.Visibility.Collapsed;
                e.Cancel = true;
            }
            else if (this.NavigationService.CanGoBack)
                this.NavigationService.GoBack();
                /*
            else
                e.Cancel = true; */
        }

        private void OnTogglePushpinViewMode(object sender, EventArgs e)
        {
            hidePushpins = !hidePushpins;
            // NotifyPropertyChanged("Pushpins");
            UpdatePins();
        }

    }
}