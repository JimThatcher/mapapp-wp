﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Globalization;
using System.Windows.Data;
using System.ComponentModel;

namespace mapapp
{
    public partial class HouseListPage : PhoneApplicationPage
    {
        CollectionViewSource cvsVoters = null;
        SortDescription sortOnHouseNum;
        GroupDescription groupOddEven;

        public HouseListPage()
        {
            InitializeComponent();

            cvsVoters = new CollectionViewSource();
            cvsVoters.Source = App.VotersViewModel;
            sortOnHouseNum = new SortDescription("HouseNum", ListSortDirection.Ascending);
            cvsVoters.SortDescriptions.Add(sortOnHouseNum);

            groupOddEven = new PropertyGroupDescription("IsEven");

            lstVoters.ItemsSource = cvsVoters.View;
        }

        private void PhoneApplicationPage_DoubleTap(object sender, GestureEventArgs e)
        {
            // Open detail page for household, collect contact data
        }

        private void ApplicationBarIconButtonSortUp_Click(object sender, EventArgs e)
        {
            cvsVoters.SortDescriptions.Clear();
            sortOnHouseNum.Direction = ListSortDirection.Ascending;
            cvsVoters.SortDescriptions.Add(sortOnHouseNum);
        }

        private void ApplicationBarIconButtonSortDown_Click(object sender, EventArgs e)
        {
            cvsVoters.SortDescriptions.Clear();
            sortOnHouseNum.Direction = ListSortDirection.Descending;
            cvsVoters.SortDescriptions.Add(sortOnHouseNum);
        }

        private void ApplicationBarIconButtonSortOddEven_Click(object sender, EventArgs e)
        {
            // cvsVoters.SortDescriptions.Clear();
            bool bIsGrouped = cvsVoters.GroupDescriptions.Count > 0;
            cvsVoters.GroupDescriptions.Clear();
            // sortOnHouseNum.Direction = ListSortDirection.Ascending;
            if (!bIsGrouped)
                cvsVoters.GroupDescriptions.Add(groupOddEven);
            // cvsVoters.SortDescriptions.Add(sortOnHouseNum);
        }
    }

    public class BoolVizConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // if (value is bool?) return ((bool)value) ? System.Windows.Visibility.Visible : System.Windows.Visibility.Visible;
            if (value is bool?) return ((bool)value) ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
            return System.Windows.Visibility.Visible;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is System.Windows.Visibility)
                return (value.Equals(System.Windows.Visibility.Visible)) ? true : false;
            return false;
        }
    }
    

}